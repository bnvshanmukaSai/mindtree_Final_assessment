using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
namespace tideSelenium
{
    public class Tests
    {
        [Test]
        public void Registration()
        {
            IWebDriver tideRE = new ChromeDriver();
            tideRE.Url = "https://tide.com/en-us";
            tideRE.FindElement(By.XPath("//button[@class='sticker_close']")).Click();
            Thread.Sleep(5000);
            tideRE.FindElement(By.XPath("//*[@id='lilo3746-wrapper']/div/a")).Click();
            tideRE.FindElement(By.XPath("//*[@id='site-header']/div[1]/div/div/div/div[2]/span/a")).Click();
            tideRE.Navigate().GoToUrl("https://www.pggoodeveryday.com/signup/tide-coupons/");
            tideRE.FindElement(By.XPath("//input[@placeholder='First name']")).SendKeys("sitaram");
            tideRE.FindElement(By.XPath("//input[@type='email']")).SendKeys("shannu@gmail.com");
            tideRE.FindElement(By.XPath("//input[@type='password']")).SendKeys("Sita@9989");
            tideRE.FindElement(By.XPath("//input[@type='submit']")).Click();
        }
        [Test]
        public void ShopProducts()
        {
            IWebDriver tideSP = new ChromeDriver();
            tideSP.Url = "https://tide.com/en-us";
            tideSP.FindElement(By.XPath("//button[@class='sticker_close']")).Click();
            Thread.Sleep(5000);
            tideSP.FindElement(By.XPath("//*[@id='lilo3746-wrapper']/div/a")).Click();
            tideSP.FindElement(By.LinkText("Shop Products")).Click();
            tideSP.Navigate().GoToUrl("https://tide.com/en-us/shop/type/powder/tide-clean-breeze-powder");
            Thread.Sleep(10000);
            tideSP.FindElement(By.XPath("//span[@class='ps-button-label']")).Click();
        }
        [Test]
        public void OurCommitment()
        {
            IWebDriver tideOC = new ChromeDriver();
            tideOC.Url = "https://tide.com/en-us";
            tideOC.Navigate().GoToUrl("https://tide.com/en-us/our-commitment");
            tideOC.FindElement(By.XPath("//*[@id='site-content']/div/div/div/div/div[2]/div/div/div/div[1]/div/div[2]/div/a[2]")).Click();
        }

        [Test]
        public void HowToWashCloths()
        {
            IWebDriver tideWC = new ChromeDriver();
            tideWC.Url = "https://tide.com/en-us";
            tideWC.FindElement(By.XPath("//button[@class='sticker_close']")).Click();
            Thread.Sleep(5000);
            tideWC.FindElement(By.XPath("//*[@id='lilo3746-wrapper']/div/a")).Click();
            tideWC.FindElement(By.LinkText("How to Wash Clothes")).Click();
            IJavaScriptExecutor js = (IJavaScriptExecutor)tideWC;
            Thread.Sleep(5000);
            js.ExecuteScript("window.scrollBy(0,950);");
        }
        [Test]
        public void WhatsNew()
        {
            IWebDriver tideWN = new ChromeDriver();
            tideWN.Url = "https://tide.com/en-us";
            tideWN.FindElement(By.XPath("//button[@class='sticker_close']")).Click();
            Thread.Sleep(5000);
            tideWN.FindElement(By.XPath("//*[@id='lilo3746-wrapper']/div/a")).Click();
            tideWN.FindElement(By.LinkText("What�s New")).Click();
            IJavaScriptExecutor js = (IJavaScriptExecutor)tideWN;
            Thread.Sleep(5000);
            js.ExecuteScript("window.scrollBy(0,950);");

        }
        [Test]
        public void ComponentsAndRewords()
        {
            IWebDriver tideCAR = new ChromeDriver();
            tideCAR.Url = "https://tide.com/en-us";
            tideCAR.FindElement(By.XPath("//button[@class='sticker_close']")).Click();
            Thread.Sleep(5000);
            tideCAR.FindElement(By.XPath("//*[@id='lilo3746-wrapper']/div/a")).Click();
            tideCAR.FindElement(By.LinkText("Coupons and Rewards")).Click();
            IJavaScriptExecutor js = (IJavaScriptExecutor)tideCAR;
            Thread.Sleep(5000);
            js.ExecuteScript("window.scrollBy(0,950);");
            tideCAR.Navigate().GoToUrl("https://www.pggoodeveryday.com/login/");
            tideCAR.FindElement(By.XPath("//input[@type='email']")).SendKeys("susarmabommakanti@gmail.com");
            tideCAR.FindElement(By.Id("login-password")).SendKeys("Shannu@9989");
            Thread.Sleep(5000);
            tideCAR.FindElement(By.XPath("//input[@type='submit']")).Click();
        }
        [Test]
        public void LiveChat()
        {
            IWebDriver tideLC = new ChromeDriver();
            tideLC.Url = "https://tide.com/en-us";
            tideLC.FindElement(By.XPath("//button[@class='sticker_close']")).Click();
            Thread.Sleep(5000);
            tideLC.FindElement(By.XPath("//*[@id='lilo3746-wrapper']/div/a")).Click();
            tideLC.FindElement(By.LinkText("Live Chat")).Click();
            tideLC.Navigate().GoToUrl("https://pgconsumersupport.secure.force.com/carehub/sf_PreChatForm?brand=Tide&country=United%20States%20of%20America&language=English-US&type=static&endpoint=https%3A%2F%2Fpgconsumersupport.secure.force.com%2Fcarehub%2Fgcr_chatPage%3Fbrand%3DTide%26country%3DUnited+States+of+America%26language%3DEnglish-US%26ETE%3D%26Source%3Dstatic%26gdpr%3Dfalse%23deployment_id%3D5728000000000qn%26button_id%3D57380000000010x%26org_id%3D00D80000000PUz7%26session_id%3Dnull");
            tideLC.FindElement(By.XPath("//button[@id='acceptGDPR']")).Click();
            tideLC.FindElement(By.XPath("//input[@id='firstNameField']")).SendKeys("shannu");
            tideLC.FindElement(By.XPath("//input[@id='lastNameField']")).SendKeys("Bommakanti");
            tideLC.FindElement(By.XPath("//input[@id='emailField']")).SendKeys("susarmabommakanti@gmail.com");
            tideLC.FindElement(By.XPath("//input[@id='test']")).Click();
        }
        [Test]
        public void SerachBar()
        {
            IWebDriver tideSB = new ChromeDriver();
            tideSB.Url = "https://tide.com/en-us";
            tideSB.FindElement(By.XPath("//button[@class='sticker_close']")).Click();
            Thread.Sleep(5000);
            tideSB.FindElement(By.XPath("//*[@id='lilo3746-wrapper']/div/a")).Click();
            IWebElement sb = tideSB.FindElement(By.XPath("//input[@type='search']"));
            sb.SendKeys("Tide Hygienic Clean Heavy Duty 10X Power");
            Thread.Sleep(2000);
            sb.SendKeys(Keys.Enter);
            IWebElement res = tideSB.FindElement(By.XPath("//*[@id='site-content']/div[2]/div/div/span"));
            Thread.Sleep(2000);
            Console.WriteLine(res.Text);
        }
        [Test]
        public void ContactUs()
        {
            IWebDriver tideCU = new ChromeDriver();
            tideCU.Url = "https://tide.com/en-us";
            tideCU.FindElement(By.XPath("//button[@class='sticker_close']")).Click();
            Thread.Sleep(5000);
            tideCU.FindElement(By.XPath("//*[@id='lilo3746-wrapper']/div/a")).Click();
            //tideCU.FindElement(By.LinkText("Contact Us")).Click();
            tideCU.Navigate().GoToUrl("https://tide.com/en-us/contact-us");
            Console.WriteLine(tideCU.Title);
            tideCU.FindElement(By.XPath("//button[@class='sticker_close']")).Click();
        }
        [Test]
        public void PopupFeedback()
        {
            IWebDriver tidePF = new ChromeDriver();
            tidePF.Url = "https://tide.com/en-us";
            tidePF.FindElement(By.XPath("//button[@class='sticker_close']")).Click();
            Thread.Sleep(5000);
            IWebElement one = tidePF.FindElement(By.LinkText("Tough stains"));
            Console.WriteLine(one.Text);
            one.Click();



        }
            
     }







       
    
}